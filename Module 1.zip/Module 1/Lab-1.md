﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿# LAB GUIDE
## Lab: App Modernization

### Pre-requisites
* Microsoft Azure Account: You'll need a valid and active Azure account for the Azure labs.


## Length
30 minutes

## Exercise 1: Migrate the database to Azure SQL Database


###Task 1: Provision a SQL Server
In this task, you will create a SQL Server (logical server). You will not create the databases at this time since it will be created during the database migration step

1. In a web browser, navigate to the Azure portal http://portal.azure.com and sign in with the credentials provided.
2. Select "+Create a resource", enter SQL Server into the Search the Marketplace box, press enter and select SQL Server (logical server)from the results.
   
![](images/25.png)

3. Select Create on the SQL server (logical server) blade
4. On the SQL Server (logical server on...) blade, specify the following configuration:
-   a. Server name: Enter a unique value, such as SQLTESTXXX Where you must change the values for XXX, (ensure the green checkmark appears).
-   b. Server admin login: demouser
-   c. Password: Password.1!!
-   d. Resource group: Select the module-01-XXXXX resource group, Where XXXXX is the number assigned to your credentials.
-   e. Location: Select the nearest location to where you are.
   
![](images/26.png)

5. Select Create.

###Task 2: Configure SQL Server firewall
In this task, you will create a firewall rule to allow access to your SQL Server

1. After the SQL Server finishes provisioning, navigate to it by select Resource groups from the left-hand menu in the Azure portal, then clcik on module-01-XXXXX resource group from the list.
   
![](images/27.png)

2. Select your SQL Server from the resources in the group.
   
![](images/28.png)

3. On the SQL Server blade, select Firewalls and virtual networks under Settings.
   
![](images/29.png)

4. On the Firewalls and virtual networks blade, specify a new rule named ALL, with START IP 0.0.0.0, and END IP 255.255.255.255, then select Save
   
![](images/30.png)

5. On the Success dialog box, select OK

###Task 3: Migrate the on-premises SQL database to Azure
In this task, you will migrate the AdventureWorks database from on-premises (Lab VM) into Azure SQL Database

1. On Azure Portal, From the Left menu, go to Virtual Machines.
 
![](images/10.png)

3. Click on MySQLVM
   
![](images/11.png)

4. On the VM’s Dashboard, click on Connect from the upper menu.
   
![](images/12.png)

5. Click on Download RDP File.
   
![](images/13.png)

6. Go to your downloads folder and double click on MySQLVM.rdp File, click on Connect, enter student as the user name and Pa55w.rd1234 as Password, and click on Accept. And then click on Yes.
   
7. Click on Star and type Management, from the results click on SQL Management Studio 17,and then click connect.
8. Click on New Query

![](images/newquery.png)

9. Type the following code and click on Execute

```
CREATE DATABASE AdventureTest
GO

USE AdventureTest
CREATE TABLE dbo.Products  
   (ProductID int PRIMARY KEY NOT NULL,  
   ProductName varchar(25) NOT NULL,  
   Price money NULL,  
   ProductDescription text NULL)  
GO
INSERT Products (ProductID, ProductName, Price)  
    VALUES (3000, 'Hammer', .52),
			(3001, 'Bag', 2),
			(3002, 'Spoon', .15),
			(3003, 'Knife', .15),
			(3004, 'Chainsaw', 13)  
GO

```

![](images/execute.png)

10. At object explorer, expand Databases and click on refresh until the AdventureTest Database appears

11. Right-click the AdventureTest database and select Tasks Deploy Database to Microsoft Azure SQL Database.

![](images/31.png)

12.  In the Deploy Database ‘AdventureTest' dialog, select Next to begin.
13.  On the Deployment Settings tab, select Connect next to Server Connection.
   
![](images/32.png)

14. In the Connect to Server dialog, enter the server name of the Azure SQL server you created previously. You can find this by navigating to your SQL Server in the Azure portal and selecting Properties.
   
![](images/33.png)

15. Next, set Authentication to SQL Server Authentication and enter the following credentials:
   a. Login: demouser
   b. Password: Password.1!!
16. Check Remember password.
17. Select Connect.
   
![](images/34.png)

18.  You should now see the Azure SQL server name in the Server connection box. Verify the new database name is AdventureTest, then, select Next.

19.  Verify the settings are correct and select Finish.
   
![](images/35.png)

20. When the operation has completed, close the database deployment dialog. You should see green checkmarks next to each completed step, along with a large checkmark next to Operation Complete.
21. You can verify that the database is operational, and its tables populated by connecting to it through SSMS, using the same credentials used in Step 15 above.


## Exercise 2: Provision App Services
### Task 1: Create a Web App
In this task, you will provision a Web App and API App in Azure.

1. In the Azure portal http://portal.azure.com, create a new Web App by selecting +Create a resource, enter "web app" in the Marketplace search box, and selecting the Web App item in the results.
   
![](images/36.png)

2. Select Create on the Web App blade.
3. On the Web App Create blade, specify the following configuration:
-   a. App name: Enter a unique and valid URL, such as myfirstappXXX Where you must change the values for XXX (until the green check mark appears) in the App Name field.
-   b. Subscription: Select the subscription you are using for this lab.
-   c. Resource group: Select Use existing, and select the resource group provided for this Module 1 lab.
   
![](images/37.png)

-   d. Select App Service plan/Location.
-   e. On the App Service plan blade, select Create new.
   
![](images/38.png)

-   f. On the New App Service Plan blade, enter the following:
-   App Service plan: Enter a unique name.
   
![](images/39.png)

-   Location: Select the location you are using for this hands-on lab.
-   Pricing tier: Select S1 Standard.
   
![](images/40.png)

4. Select OK.
5. Select Create to provision the new Web App.

### Task 2: Provision an API App
1. In the Azure portal http://portal.azure.com, select +Create a resource, enter "api app" in the Marketplace Search box, and select API App from the results.
   
![](images/41.png)

2. Select Create on the API App blade.
3. On the API App Create blade, enter the following:
-   a. App name: Enter a unique name, such as mynewapiXXX. Where you must change the values for XXX, (ensure the green checkmark appears).
-   b. Subscription: Select the subscription you are using for this hands-on lab.
-   c. Resource group: Choose Use existing, and select the resource group provided for this Module 1 lab.
-   d. App Service plan/Location: Select the plan you created for the Web App.
   
![](images/42.png)

4. Select Create.

## Exercise 3: Connect your App with the Azure SQL Database

### Task 1: Get the connection String

1. On the azure portal, from the left menu, click on SQL databases
2. Select the AdventureTest Database you just migrated.
3. From the AverntureTest blade, click on Connection strings

![](images/cstrings.png)

4. Selec the ADO.NET connections string and click on the copy button, note that you will need to change the information with your username and password

![](images/ado.png) 

### Task 2: Add the connection string to your Web App

1.- On the Azure Portal from the lef menu, click on App Services, and then click on the App you just created on Exercise 2

![](images/app.png)

2.- On the Web App blade, under settings click on Application Settings, scroll down to find the connections strings section and click on +Add new connection string

![](images/appsettings.png)

3.- On Connection String Name Type democs, on Value paste the connection string that you obtained on the past task, cahnge the values from username and password with demouser and Password.1!!, Ensure that SQLAzure is selected on Type dropdown text, and the click on Save at the top of the workspace

![](images/appcs.png)

4.- NOTE: You can name the connection strings to match with the connection strings you use on your code.

## Exercise 4: Identity and security

### Task 1: Protect your WebApp with Azure Identity.

1. In the Azure portal, navigate to your Web App you created on the Exercise 3 (Select, App Services in the left menu, and then your app). In the left navigation, select Authentication / Authorization
   
![](images/48.png)

2. If Authentication / Authorization is not enabled, select On.
   
![](images/49.png)

3. Under Action to take when request is not authenticated, select Log in with Azure Active Directory.
4. Under Authentication Providers, Select Azure Active Directory, and then select Express under Management Mode.
   
![](images/50.png)

5. Select OK to register the App Service app in Azure Active Directory. This creates a new app registration. 
6. Click Save.

You are now ready to use Azure Active Directory for authentication in your App Service app.

### Task 2: Test the protection.
1. From the App Services Blade, click on OverView.
2. Under URL on the dashboard click on the link to test the Authentication you just Enabled.
3. Sign in with the azure account provided for this lab

Note that the wep app you just created now is portected with Azure Active Directory Identity


End of the lab




















